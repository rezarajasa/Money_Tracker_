-- =============================================================
-- RapiKas Money Tracker Pro - Multi-Currency / Kurs Module
-- Jalankan setelah schema utama jika project Anda sudah pernah dibuat.
-- Jika Anda memakai schema.sql dari paket ini, module ini juga sudah ditambahkan di bawah.
-- =============================================================

-- 1. Tambahan kolom mata uang untuk tabel utama
alter table public.wallets
  add column if not exists currency_code text not null default 'IDR';

alter table public.transactions
  add column if not exists currency_code text not null default 'IDR',
  add column if not exists exchange_rate_to_base numeric(18,8) not null default 1,
  add column if not exists base_currency_code text not null default 'IDR',
  add column if not exists base_amount numeric(18,2);

alter table public.transfers
  add column if not exists from_currency_code text not null default 'IDR',
  add column if not exists to_currency_code text not null default 'IDR',
  add column if not exists exchange_rate numeric(18,8) not null default 1;

alter table public.budgets
  add column if not exists currency_code text not null default 'IDR',
  add column if not exists base_currency_code text not null default 'IDR',
  add column if not exists base_amount numeric(18,2);

alter table public.goals
  add column if not exists currency_code text not null default 'IDR',
  add column if not exists base_currency_code text not null default 'IDR',
  add column if not exists base_target_amount numeric(18,2),
  add column if not exists base_current_amount numeric(18,2);

-- 2. Master mata uang yang didukung
create table if not exists public.supported_currencies (
  code text primary key,
  name text not null,
  country text,
  symbol text,
  decimal_digits int not null default 2,
  is_popular boolean not null default false,
  sort_order int not null default 999,
  created_at timestamptz not null default now()
);

-- 3. Kurs harian terhadap IDR
create table if not exists public.currency_rates (
  id uuid primary key default gen_random_uuid(),
  base_code text not null default 'IDR',
  currency_code text not null references public.supported_currencies(code) on delete cascade,
  buy_rate numeric(18,8) not null check (buy_rate > 0),
  sell_rate numeric(18,8) not null check (sell_rate > 0),
  mid_rate numeric(18,8) generated always as ((buy_rate + sell_rate) / 2) stored,
  rate_date date not null default current_date,
  provider text not null default 'manual',
  is_manual boolean not null default false,
  raw_payload jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (base_code, currency_code, rate_date, provider)
);

-- 4. Preferensi kurs per user
create table if not exists public.user_currency_preferences (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade unique,
  base_currency_code text not null default 'IDR' references public.supported_currencies(code),
  favorite_currency_codes text[] not null default array['USD','EUR','SAR','SGD','MYR'],
  auto_update_rates boolean not null default true,
  rate_provider text not null default 'frankfurter',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 5. Seed currencies populer + beberapa mata uang umum
insert into public.supported_currencies (code, name, country, symbol, decimal_digits, is_popular, sort_order)
values
  ('IDR','Rupiah Indonesia','Indonesia','Rp',0,true,1),
  ('USD','US Dollar','Amerika Serikat','$',2,true,2),
  ('EUR','Euro','Uni Eropa','€',2,true,3),
  ('SAR','Saudi Riyal','Arab Saudi','﷼',2,true,4),
  ('SGD','Singapore Dollar','Singapura','S$',2,true,5),
  ('MYR','Malaysian Ringgit','Malaysia','RM',2,true,6),
  ('JPY','Japanese Yen','Jepang','¥',0,true,7),
  ('GBP','Pound Sterling','Inggris','£',2,true,8),
  ('AUD','Australian Dollar','Australia','A$',2,true,9),
  ('AED','UAE Dirham','Uni Emirat Arab','د.إ',2,true,10),
  ('CNY','Chinese Yuan','Tiongkok','¥',2,true,11),
  ('KRW','South Korean Won','Korea Selatan','₩',0,true,12),
  ('THB','Thai Baht','Thailand','฿',2,true,13),
  ('CHF','Swiss Franc','Swiss','CHF',2,false,14),
  ('CAD','Canadian Dollar','Kanada','C$',2,false,15),
  ('HKD','Hong Kong Dollar','Hong Kong','HK$',2,false,16),
  ('INR','Indian Rupee','India','₹',2,false,17),
  ('PHP','Philippine Peso','Filipina','₱',2,false,18),
  ('VND','Vietnamese Dong','Vietnam','₫',0,false,19),
  ('TRY','Turkish Lira','Turki','₺',2,false,20)
on conflict (code) do update set
  name = excluded.name,
  country = excluded.country,
  symbol = excluded.symbol,
  decimal_digits = excluded.decimal_digits,
  is_popular = excluded.is_popular,
  sort_order = excluded.sort_order;

-- 6. Seed kurs contoh. Untuk production, isi otomatis dari Edge Function / API provider.
insert into public.currency_rates (base_code, currency_code, buy_rate, sell_rate, rate_date, provider, is_manual)
values
  ('IDR','IDR',1,1,current_date,'base',false),
  ('IDR','USD',16150,16300,current_date,'sample',true),
  ('IDR','EUR',17450,17700,current_date,'sample',true),
  ('IDR','GBP',20300,20650,current_date,'sample',true),
  ('IDR','JPY',103,107,current_date,'sample',true),
  ('IDR','SAR',4300,4380,current_date,'sample',true),
  ('IDR','AED',4380,4460,current_date,'sample',true),
  ('IDR','SGD',11800,12050,current_date,'sample',true),
  ('IDR','MYR',3400,3500,current_date,'sample',true),
  ('IDR','AUD',10450,10750,current_date,'sample',true),
  ('IDR','CAD',11800,12100,current_date,'sample',true),
  ('IDR','CHF',18500,19050,current_date,'sample',true),
  ('IDR','CNY',2210,2270,current_date,'sample',true),
  ('IDR','HKD',2050,2110,current_date,'sample',true),
  ('IDR','KRW',11.3,12.1,current_date,'sample',true),
  ('IDR','THB',440,465,current_date,'sample',true),
  ('IDR','INR',190,200,current_date,'sample',true),
  ('IDR','PHP',280,292,current_date,'sample',true),
  ('IDR','VND',0.61,0.67,current_date,'sample',true),
  ('IDR','TRY',485,520,current_date,'sample',true)
on conflict (base_code, currency_code, rate_date, provider) do update set
  buy_rate = excluded.buy_rate,
  sell_rate = excluded.sell_rate,
  is_manual = excluded.is_manual,
  updated_at = now();

-- 7. View untuk kurs terbaru per currency
create or replace view public.v_latest_currency_rates as
select distinct on (currency_code)
  currency_code,
  base_code,
  buy_rate,
  sell_rate,
  mid_rate,
  rate_date,
  provider,
  is_manual,
  updated_at
from public.currency_rates
order by currency_code, rate_date desc, updated_at desc;

-- 8. View dompet dengan nilai setara IDR
create or replace view public.v_wallets_with_base_value as
select
  w.*,
  coalesce(r.mid_rate, 1) as exchange_rate_to_idr,
  round(w.balance * coalesce(r.mid_rate, 1), 2) as balance_idr
from public.wallets w
left join public.v_latest_currency_rates r on r.currency_code = w.currency_code;

-- 9. Trigger updated_at untuk tabel kurs
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_currency_rates_updated_at on public.currency_rates;
create trigger trg_currency_rates_updated_at before update on public.currency_rates
for each row execute function public.set_updated_at();

drop trigger if exists trg_user_currency_preferences_updated_at on public.user_currency_preferences;
create trigger trg_user_currency_preferences_updated_at before update on public.user_currency_preferences
for each row execute function public.set_updated_at();

-- 10. RLS
alter table public.supported_currencies enable row level security;
alter table public.currency_rates enable row level security;
alter table public.user_currency_preferences enable row level security;

drop policy if exists supported_currencies_select_all on public.supported_currencies;
drop policy if exists currency_rates_select_all on public.currency_rates;
drop policy if exists user_currency_preferences_all_own on public.user_currency_preferences;

create policy supported_currencies_select_all on public.supported_currencies
for select using (true);

create policy currency_rates_select_all on public.currency_rates
for select using (true);

create policy user_currency_preferences_all_own on public.user_currency_preferences
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- 11. Catatan:
-- - currency_rates sengaja bisa dibaca semua user, karena data kurs bukan data pribadi.
-- - Insert/update kurs sebaiknya dilakukan server-side via Supabase Edge Function memakai service role.
-- - Jangan menaruh service_role key di APK.
-- =============================================================
