import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config/app_config.dart';
import 'services/supabase_service.dart';
import 'utils/money_formatter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.isSupabaseConfigured) {
    await SupabaseService.init();
  }
  runApp(const RapiKasApp());
}

enum TransactionType { income, expense }

class Wallet {
  final String id;
  final String name;
  final String type;
  final double balance;
  final String currencyCode;
  final IconData icon;

  const Wallet({
    required this.id,
    required this.name,
    required this.type,
    required this.balance,
    required this.currencyCode,
    required this.icon,
  });

  Wallet copyWith({double? balance}) => Wallet(
        id: id,
        name: name,
        type: type,
        balance: balance ?? this.balance,
        currencyCode: currencyCode,
        icon: icon,
      );
}

class MoneyCategory {
  final String id;
  final String name;
  final TransactionType type;
  final IconData icon;
  final Color color;

  const MoneyCategory({
    required this.id,
    required this.name,
    required this.type,
    required this.icon,
    required this.color,
  });
}

class MoneyTransaction {
  final String id;
  final TransactionType type;
  final double amount;
  final String currencyCode;
  final String walletId;
  final String categoryId;
  final String note;
  final DateTime date;

  const MoneyTransaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.currencyCode,
    required this.walletId,
    required this.categoryId,
    required this.note,
    required this.date,
  });
}

class Budget {
  final String id;
  final String categoryId;
  final double amountBase;

  const Budget({required this.id, required this.categoryId, required this.amountBase});
}

class CurrencyRate {
  final String code;
  final String name;
  final String country;
  final String symbol;
  final double buyRateToIdr;
  final double sellRateToIdr;
  final DateTime updatedAt;
  final String source;

  const CurrencyRate({
    required this.code,
    required this.name,
    required this.country,
    required this.symbol,
    required this.buyRateToIdr,
    required this.sellRateToIdr,
    required this.updatedAt,
    required this.source,
  });

  double get midRateToIdr => (buyRateToIdr + sellRateToIdr) / 2;
}

class AppState extends ChangeNotifier {
  bool authReady = false;
  bool isLoggedIn = false;
  String? userEmail;
  StreamSubscription<AuthState>? _authSubscription;
  int selectedTab = 0;
  String baseCurrency = 'IDR';

  final List<CurrencyRate> currencyRates = [
    CurrencyRate(code: 'IDR', name: 'Rupiah Indonesia', country: 'Indonesia', symbol: 'Rp', buyRateToIdr: 1, sellRateToIdr: 1, updatedAt: DateTime.now(), source: 'Base currency'),
    CurrencyRate(code: 'USD', name: 'US Dollar', country: 'Amerika Serikat', symbol: '\$', buyRateToIdr: 16150, sellRateToIdr: 16300, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'EUR', name: 'Euro', country: 'Uni Eropa', symbol: '€', buyRateToIdr: 17450, sellRateToIdr: 17700, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'GBP', name: 'Pound Sterling', country: 'Inggris', symbol: '£', buyRateToIdr: 20300, sellRateToIdr: 20650, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'JPY', name: 'Japanese Yen', country: 'Jepang', symbol: '¥', buyRateToIdr: 103, sellRateToIdr: 107, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'SAR', name: 'Saudi Riyal', country: 'Arab Saudi', symbol: '﷼', buyRateToIdr: 4300, sellRateToIdr: 4380, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'AED', name: 'UAE Dirham', country: 'Uni Emirat Arab', symbol: 'د.إ', buyRateToIdr: 4380, sellRateToIdr: 4460, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'SGD', name: 'Singapore Dollar', country: 'Singapura', symbol: 'S\$', buyRateToIdr: 11800, sellRateToIdr: 12050, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'MYR', name: 'Malaysian Ringgit', country: 'Malaysia', symbol: 'RM', buyRateToIdr: 3400, sellRateToIdr: 3500, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'AUD', name: 'Australian Dollar', country: 'Australia', symbol: 'A\$', buyRateToIdr: 10450, sellRateToIdr: 10750, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'CAD', name: 'Canadian Dollar', country: 'Kanada', symbol: 'C\$', buyRateToIdr: 11800, sellRateToIdr: 12100, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'CHF', name: 'Swiss Franc', country: 'Swiss', symbol: 'CHF', buyRateToIdr: 18500, sellRateToIdr: 19050, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'CNY', name: 'Chinese Yuan', country: 'Tiongkok', symbol: '¥', buyRateToIdr: 2210, sellRateToIdr: 2270, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'HKD', name: 'Hong Kong Dollar', country: 'Hong Kong', symbol: 'HK\$', buyRateToIdr: 2050, sellRateToIdr: 2110, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'KRW', name: 'South Korean Won', country: 'Korea Selatan', symbol: '₩', buyRateToIdr: 11.3, sellRateToIdr: 12.1, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'THB', name: 'Thai Baht', country: 'Thailand', symbol: '฿', buyRateToIdr: 440, sellRateToIdr: 465, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'INR', name: 'Indian Rupee', country: 'India', symbol: '₹', buyRateToIdr: 190, sellRateToIdr: 200, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'PHP', name: 'Philippine Peso', country: 'Filipina', symbol: '₱', buyRateToIdr: 280, sellRateToIdr: 292, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'VND', name: 'Vietnamese Dong', country: 'Vietnam', symbol: '₫', buyRateToIdr: 0.61, sellRateToIdr: 0.67, updatedAt: DateTime.now(), source: 'Sample rate'),
    CurrencyRate(code: 'TRY', name: 'Turkish Lira', country: 'Turki', symbol: '₺', buyRateToIdr: 485, sellRateToIdr: 520, updatedAt: DateTime.now(), source: 'Sample rate'),
  ];

  final List<Wallet> wallets = [
    const Wallet(id: 'cash', name: 'Cash', type: 'Tunai', balance: 850000, currencyCode: 'IDR', icon: Icons.payments_rounded),
    const Wallet(id: 'bank', name: 'Bank BCA', type: 'Rekening', balance: 3250000, currencyCode: 'IDR', icon: Icons.account_balance_rounded),
    const Wallet(id: 'ewallet', name: 'E-Wallet', type: 'Digital', balance: 420000, currencyCode: 'IDR', icon: Icons.account_balance_wallet_rounded),
    const Wallet(id: 'usd_saving', name: 'Tabungan USD', type: 'Valas', balance: 120, currencyCode: 'USD', icon: Icons.savings_rounded),
  ];

  final List<MoneyCategory> categories = [
    const MoneyCategory(id: 'salary', name: 'Gaji', type: TransactionType.income, icon: Icons.work_rounded, color: Color(0xFF22C55E)),
    const MoneyCategory(id: 'business', name: 'Usaha', type: TransactionType.income, icon: Icons.store_rounded, color: Color(0xFF14B8A6)),
    const MoneyCategory(id: 'gift', name: 'Hadiah', type: TransactionType.income, icon: Icons.card_giftcard_rounded, color: Color(0xFF84CC16)),
    const MoneyCategory(id: 'food', name: 'Makanan', type: TransactionType.expense, icon: Icons.restaurant_rounded, color: Color(0xFFF97316)),
    const MoneyCategory(id: 'transport', name: 'Transportasi', type: TransactionType.expense, icon: Icons.directions_car_rounded, color: Color(0xFF3B82F6)),
    const MoneyCategory(id: 'shopping', name: 'Belanja', type: TransactionType.expense, icon: Icons.shopping_bag_rounded, color: Color(0xFFA855F7)),
    const MoneyCategory(id: 'education', name: 'Pendidikan', type: TransactionType.expense, icon: Icons.school_rounded, color: Color(0xFF06B6D4)),
    const MoneyCategory(id: 'charity', name: 'Sedekah', type: TransactionType.expense, icon: Icons.volunteer_activism_rounded, color: Color(0xFF10B981)),
    const MoneyCategory(id: 'bills', name: 'Tagihan', type: TransactionType.expense, icon: Icons.receipt_long_rounded, color: Color(0xFFEF4444)),
    const MoneyCategory(id: 'travel', name: 'Travel / Umrah', type: TransactionType.expense, icon: Icons.flight_takeoff_rounded, color: Color(0xFF0EA5E9)),
  ];

  final List<MoneyTransaction> transactions = [
    MoneyTransaction(id: 't1', type: TransactionType.income, amount: 3500000, currencyCode: 'IDR', walletId: 'bank', categoryId: 'salary', note: 'Gaji bulanan', date: DateTime.now().subtract(const Duration(days: 3))),
    MoneyTransaction(id: 't2', type: TransactionType.expense, amount: 45000, currencyCode: 'IDR', walletId: 'cash', categoryId: 'food', note: 'Makan siang', date: DateTime.now().subtract(const Duration(days: 1))),
    MoneyTransaction(id: 't3', type: TransactionType.expense, amount: 22, currencyCode: 'USD', walletId: 'usd_saving', categoryId: 'travel', note: 'Contoh transaksi valas', date: DateTime.now()),
    MoneyTransaction(id: 't4', type: TransactionType.expense, amount: 150000, currencyCode: 'IDR', walletId: 'bank', categoryId: 'shopping', note: 'Belanja kebutuhan', date: DateTime.now()),
  ];

  final List<Budget> budgets = const [
    Budget(id: 'b1', categoryId: 'food', amountBase: 1200000),
    Budget(id: 'b2', categoryId: 'transport', amountBase: 600000),
    Budget(id: 'b3', categoryId: 'shopping', amountBase: 800000),
    Budget(id: 'b4', categoryId: 'bills', amountBase: 1000000),
    Budget(id: 'b5', categoryId: 'travel', amountBase: 2500000),
  ];

  void bootstrapAuth() {
    if (!AppConfig.isSupabaseConfigured) {
      authReady = true;
      notifyListeners();
      return;
    }

    final user = SupabaseService.client.auth.currentUser;
    isLoggedIn = user != null;
    userEmail = user?.email;
    authReady = true;
    notifyListeners();

    _authSubscription ??= SupabaseService.client.auth.onAuthStateChange.listen((data) {
      final session = data.session;
      isLoggedIn = session != null;
      userEmail = session?.user.email;
      if (!isLoggedIn) selectedTab = 0;
      notifyListeners();
    });
  }

  Future<String?> loginWithEmail({required String email, required String password}) async {
    if (!AppConfig.isSupabaseConfigured) {
      return 'Supabase belum dikonfigurasi. Isi SUPABASE_URL dan SUPABASE_ANON_KEY di lib/config/app_config.dart.';
    }
    try {
      final response = await SupabaseService.signInWithEmail(email: email.trim(), password: password);
      isLoggedIn = response.session != null;
      userEmail = response.user?.email;
      notifyListeners();
      return null;
    } on AuthException catch (error) {
      return error.message;
    } catch (_) {
      return 'Login gagal. Periksa koneksi internet dan konfigurasi Supabase.';
    }
  }

  Future<String?> registerWithEmail({required String name, required String email, required String password}) async {
    if (!AppConfig.isSupabaseConfigured) {
      return 'Supabase belum dikonfigurasi. Isi SUPABASE_URL dan SUPABASE_ANON_KEY di lib/config/app_config.dart.';
    }
    if (password.length < 6) return 'Password minimal 6 karakter.';
    try {
      final response = await SupabaseService.signUpWithEmail(email: email.trim(), password: password, fullName: name.trim());
      isLoggedIn = response.session != null;
      userEmail = response.user?.email ?? email.trim();
      notifyListeners();
      return null;
    } on AuthException catch (error) {
      return error.message;
    } catch (_) {
      return 'Daftar akun gagal. Periksa koneksi internet dan pengaturan Auth di Supabase.';
    }
  }

  Future<String?> sendResetPassword(String email) async {
    if (!AppConfig.isSupabaseConfigured) {
      return 'Supabase belum dikonfigurasi.';
    }
    try {
      await SupabaseService.resetPassword(email.trim());
      return null;
    } on AuthException catch (error) {
      return error.message;
    } catch (_) {
      return 'Gagal mengirim email reset password.';
    }
  }

  Future<String?> loginWithGoogle() async {
    if (!AppConfig.isSupabaseConfigured) {
      return 'Supabase belum dikonfigurasi. Aktifkan dulu project Supabase Anda.';
    }
    try {
      final launched = await SupabaseService.signInWithGoogle();
      return launched ? null : 'Tidak bisa membuka halaman Google Login.';
    } on AuthException catch (error) {
      return error.message;
    } catch (_) {
      return 'Google login gagal. Periksa Provider Google dan Redirect URL di Supabase.';
    }
  }

  void loginDemo() {
    isLoggedIn = true;
    userEmail = 'demo@rapikas.app';
    notifyListeners();
  }

  Future<void> logout() async {
    if (AppConfig.isSupabaseConfigured) {
      await SupabaseService.signOut();
    }
    isLoggedIn = false;
    userEmail = null;
    selectedTab = 0;
    notifyListeners();
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }

  void changeTab(int index) {
    selectedTab = index;
    notifyListeners();
  }

  CurrencyRate rateByCode(String code) => currencyRates.firstWhere((rate) => rate.code == code, orElse: () => currencyRates.first);

  double convertAmount(double amount, String fromCode, String toCode) {
    if (fromCode == toCode) return amount;
    final fromRate = rateByCode(fromCode).midRateToIdr;
    final toRate = rateByCode(toCode).midRateToIdr;
    return amount * fromRate / toRate;
  }

  double toBase(double amount, String currencyCode) => convertAmount(amount, currencyCode, baseCurrency);

  double get totalBalanceBase => wallets.fold(0, (sum, wallet) => sum + toBase(wallet.balance, wallet.currencyCode));

  double get monthlyIncome => transactions.where((transaction) => transaction.type == TransactionType.income && _isThisMonth(transaction.date)).fold(0, (sum, transaction) => sum + toBase(transaction.amount, transaction.currencyCode));

  double get monthlyExpense => transactions.where((transaction) => transaction.type == TransactionType.expense && _isThisMonth(transaction.date)).fold(0, (sum, transaction) => sum + toBase(transaction.amount, transaction.currencyCode));

  double get totalBudget => budgets.fold(0, (sum, budget) => sum + budget.amountBase);

  double get remainingBudget => totalBudget - monthlyExpense;

  bool _isThisMonth(DateTime date) {
    final now = DateTime.now();
    return date.month == now.month && date.year == now.year;
  }

  MoneyCategory categoryById(String id) => categories.firstWhere((category) => category.id == id);

  Wallet walletById(String id) => wallets.firstWhere((wallet) => wallet.id == id);

  double spentByCategory(String categoryId) => transactions
      .where((transaction) => transaction.type == TransactionType.expense && transaction.categoryId == categoryId && _isThisMonth(transaction.date))
      .fold(0, (sum, transaction) => sum + toBase(transaction.amount, transaction.currencyCode));

  void addTransaction({
    required TransactionType type,
    required double amount,
    required String currencyCode,
    required String walletId,
    required String categoryId,
    required String note,
  }) {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    transactions.insert(
      0,
      MoneyTransaction(
        id: id,
        type: type,
        amount: amount,
        currencyCode: currencyCode,
        walletId: walletId,
        categoryId: categoryId,
        note: note,
        date: DateTime.now(),
      ),
    );

    final walletIndex = wallets.indexWhere((wallet) => wallet.id == walletId);
    if (walletIndex != -1) {
      final wallet = wallets[walletIndex];
      final walletAmount = convertAmount(amount, currencyCode, wallet.currencyCode);
      final newBalance = type == TransactionType.income ? wallet.balance + walletAmount : wallet.balance - walletAmount;
      wallets[walletIndex] = wallet.copyWith(balance: newBalance);
    }
    notifyListeners();
  }
}

class RapiKasApp extends StatefulWidget {
  const RapiKasApp({super.key});

  @override
  State<RapiKasApp> createState() => _RapiKasAppState();
}

class _RapiKasAppState extends State<RapiKasApp> {
  final AppState appState = AppState();

  @override
  void initState() {
    super.initState();
    appState.bootstrapAuth();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      appState: appState,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: AppConfig.appName,
        themeMode: ThemeMode.system,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        home: AnimatedBuilder(
          animation: appState,
          builder: (context, _) {
            if (!appState.authReady) return const SplashLoadingScreen();
            return appState.isLoggedIn ? const AppShell() : const AuthScreen();
          },
        ),
      ),
    );
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState appState, required super.child}) : super(notifier: appState);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope not found');
    return scope!.notifier!;
  }
}

class AppTheme {
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF10B981), brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7FAF9),
        appBarTheme: const AppBarTheme(elevation: 0, centerTitle: false, backgroundColor: Color(0xFFF7FAF9)),
      );

  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF10B981), brightness: Brightness.dark),
      );
}

class SplashLoadingScreen extends StatelessWidget {
  const SplashLoadingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Membuka RapiKas...'),
          ],
        ),
      ),
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isRegister = false;
  bool isLoading = false;
  bool obscurePassword = true;
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final app = AppScope.of(context);
    final email = emailController.text.trim();
    final password = passwordController.text;
    if (email.isEmpty || !email.contains('@')) {
      _showMessage('Masukkan email yang valid.');
      return;
    }
    if (password.isEmpty) {
      _showMessage('Masukkan password.');
      return;
    }

    setState(() => isLoading = true);
    final error = isRegister
        ? await app.registerWithEmail(name: nameController.text, email: email, password: password)
        : await app.loginWithEmail(email: email, password: password);
    if (!mounted) return;
    setState(() => isLoading = false);
    if (error != null) {
      _showMessage(error);
    } else if (isRegister) {
      _showMessage('Akun berhasil dibuat. Jika email confirmation aktif, cek inbox email Anda.');
    }
  }

  Future<void> _resetPassword() async {
    final app = AppScope.of(context);
    final email = emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      _showMessage('Isi email dulu untuk reset password.');
      return;
    }
    setState(() => isLoading = true);
    final error = await app.sendResetPassword(email);
    if (!mounted) return;
    setState(() => isLoading = false);
    _showMessage(error ?? 'Link reset password sudah dikirim ke email.');
  }

  Future<void> _googleLogin() async {
    final app = AppScope.of(context);
    setState(() => isLoading = true);
    final error = await app.loginWithGoogle();
    if (!mounted) return;
    setState(() => isLoading = false);
    if (error != null) _showMessage(error);
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 48),
            Container(
              height: 76,
              width: 76,
              alignment: Alignment.center,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF10B981), Color(0xFF14B8A6)])),
              child: const Icon(Icons.account_balance_wallet_rounded, color: Colors.white, size: 38),
            ),
            const SizedBox(height: 28),
            Text(AppConfig.appName, style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.w900, letterSpacing: -1)),
            const SizedBox(height: 8),
            Text('Money tracker lengkap dengan multi-kurs, budget, laporan, dan info valas.', style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.grey.shade600, height: 1.35)),
            const SizedBox(height: 28),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, icon: Icon(Icons.login_rounded), label: Text('Masuk')),
                ButtonSegment(value: true, icon: Icon(Icons.person_add_alt_1_rounded), label: Text('Daftar')),
              ],
              selected: {isRegister},
              onSelectionChanged: isLoading ? null : (value) => setState(() => isRegister = value.first),
            ),
            const SizedBox(height: 18),
            if (isRegister) ...[
              _AuthField(controller: nameController, label: 'Nama lengkap', icon: Icons.person_rounded),
              const SizedBox(height: 14),
            ],
            _AuthField(controller: emailController, label: 'Email', icon: Icons.mail_rounded, keyboardType: TextInputType.emailAddress),
            const SizedBox(height: 14),
            _AuthField(
              controller: passwordController,
              label: 'Password',
              icon: Icons.lock_rounded,
              obscure: obscurePassword,
              suffix: IconButton(
                onPressed: () => setState(() => obscurePassword = !obscurePassword),
                icon: Icon(obscurePassword ? Icons.visibility_rounded : Icons.visibility_off_rounded),
              ),
            ),
            const SizedBox(height: 10),
            if (!isRegister)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(onPressed: isLoading ? null : _resetPassword, child: const Text('Lupa password?')),
              ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: FilledButton(
                onPressed: isLoading ? null : _submit,
                style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                child: isLoading ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Text(isRegister ? 'Buat Akun' : 'Masuk'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: OutlinedButton.icon(
                onPressed: isLoading ? null : _googleLogin,
                icon: const Icon(Icons.g_mobiledata_rounded, size: 32),
                label: const Text('Login dengan Google'),
                style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
              ),
            ),
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: isLoading ? null : app.loginDemo,
              icon: const Icon(Icons.play_circle_rounded),
              label: const Text('Coba mode demo tanpa Supabase'),
            ),
            const SizedBox(height: 24),
            ModernCard(
              padding: const EdgeInsets.all(14),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.info_rounded, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    AppConfig.isSupabaseConfigured
                        ? 'Login Supabase aktif. Data user akan mengikuti akun yang masuk.'
                        : 'Supabase belum dikonfigurasi. Isi URL dan anon key di lib/config/app_config.dart agar login asli aktif.',
                    style: TextStyle(color: Colors.grey.shade700, height: 1.35),
                  ),
                ),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class _AuthField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final TextInputType? keyboardType;

  const _AuthField({required this.controller, required this.label, required this.icon, this.obscure = false, this.suffix, this.keyboardType});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon), suffixIcon: suffix, filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)),
    );
  }
}

class AppShell extends StatelessWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final screens = const [DashboardScreen(), TransactionsScreen(), BudgetScreen(), ReportsScreen(), CurrencyScreen(), ProfileScreen()];
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Scaffold(
        body: IndexedStack(index: app.selectedTab, children: screens),
        floatingActionButton: app.selectedTab == 4
            ? null
            : FloatingActionButton.extended(
                onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, useSafeArea: true, builder: (_) => AppScope(appState: app, child: const AddTransactionSheet())),
                icon: const Icon(Icons.add_rounded),
                label: const Text('Catat'),
              ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: app.selectedTab,
          onDestinationSelected: app.changeTab,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.list_alt_rounded), label: 'Transaksi'),
            NavigationDestination(icon: Icon(Icons.pie_chart_rounded), label: 'Budget'),
            NavigationDestination(icon: Icon(Icons.bar_chart_rounded), label: 'Laporan'),
            NavigationDestination(icon: Icon(Icons.currency_exchange_rounded), label: 'Kurs'),
            NavigationDestination(icon: Icon(Icons.person_rounded), label: 'Profil'),
          ],
        ),
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Assalamualaikum 👋', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)), Text('Ringkasan Keuangan', style: TextStyle(fontWeight: FontWeight.w900))]),
          actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded))],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 120),
          children: [
            BalanceCard(balance: app.totalBalanceBase, currencyCode: app.baseCurrency),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: MetricCard(title: 'Pemasukan', value: app.monthlyIncome, icon: Icons.arrow_downward_rounded, accent: const Color(0xFF10B981), currencyCode: app.baseCurrency)),
              const SizedBox(width: 12),
              Expanded(child: MetricCard(title: 'Pengeluaran', value: app.monthlyExpense, icon: Icons.arrow_upward_rounded, accent: const Color(0xFFEF4444), currencyCode: app.baseCurrency)),
            ]),
            const SizedBox(height: 16),
            ModernCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Insight AI', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF10B981).withOpacity(.12), borderRadius: BorderRadius.circular(999)), child: const Text('Beta', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF059669)))),
                ]),
                const SizedBox(height: 12),
                Text(app.remainingBudget >= 0 ? 'Keuangan bulan ini masih aman. Sisa budget sekitar ${MoneyFormatter.idr(app.remainingBudget)}. Saldo valas sudah dikonversi ke IDR.' : 'Pengeluaran sudah melewati budget. Kurangi kategori non-prioritas minggu ini.', style: TextStyle(color: Colors.grey.shade700, height: 1.45)),
              ]),
            ),
            const SizedBox(height: 16),
            const SectionTitle(title: 'Ringkasan Kurs'),
            const SizedBox(height: 10),
            CurrencyMiniCard(rate: app.rateByCode('USD')),
            CurrencyMiniCard(rate: app.rateByCode('SAR')),
            CurrencyMiniCard(rate: app.rateByCode('SGD')),
            const SizedBox(height: 16),
            const SectionTitle(title: 'Dompet Saya'),
            const SizedBox(height: 10),
            ...app.wallets.map((wallet) => WalletTile(wallet: wallet)),
            const SizedBox(height: 16),
            const SectionTitle(title: 'Transaksi Terbaru'),
            const SizedBox(height: 10),
            ...app.transactions.take(5).map((transaction) => TransactionTile(transaction: transaction)),
          ],
        ),
      ),
    );
  }
}

class BalanceCard extends StatelessWidget {
  final double balance;
  final String currencyCode;

  const BalanceCard({super.key, required this.balance, required this.currencyCode});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF064E3B), Color(0xFF10B981), Color(0xFF14B8A6)]), boxShadow: [BoxShadow(color: const Color(0xFF10B981).withOpacity(.28), blurRadius: 28, offset: const Offset(0, 14))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Total Saldo Setara $currencyCode', style: TextStyle(color: Colors.white.withOpacity(.80))), Icon(Icons.visibility_rounded, color: Colors.white.withOpacity(.82))]),
        const SizedBox(height: 14),
        Text(MoneyFormatter.format(balance, currency: currencyCode), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: -1)),
        const SizedBox(height: 18),
        const Row(children: [_MiniAction(icon: Icons.add_rounded, label: 'Income'), SizedBox(width: 10), _MiniAction(icon: Icons.remove_rounded, label: 'Expense'), SizedBox(width: 10), _MiniAction(icon: Icons.currency_exchange_rounded, label: 'Kurs')]),
      ]),
    );
  }
}

class _MiniAction extends StatelessWidget {
  final IconData icon;
  final String label;

  const _MiniAction({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(18)), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: Colors.white, size: 18), const SizedBox(width: 6), Flexible(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis))])),
    );
  }
}

class MetricCard extends StatelessWidget {
  final String title;
  final double value;
  final IconData icon;
  final Color accent;
  final String currencyCode;

  const MetricCard({super.key, required this.title, required this.value, required this.icon, required this.accent, this.currencyCode = 'IDR'});

  @override
  Widget build(BuildContext context) {
    return ModernCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        CircleAvatar(backgroundColor: accent.withOpacity(.12), foregroundColor: accent, child: Icon(icon)),
        const SizedBox(height: 12),
        Text(title, style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Text(MoneyFormatter.format(value, currency: currencyCode), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class ModernCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;

  const ModernCard({super.key, required this.child, this.padding = const EdgeInsets.all(18)});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: padding,
      decoration: BoxDecoration(color: isDark ? const Color(0xFF151515) : Colors.white, borderRadius: BorderRadius.circular(26), border: Border.all(color: isDark ? Colors.white12 : Colors.black.withOpacity(.04)), boxShadow: isDark ? [] : [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 24, offset: const Offset(0, 12))]),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;

  const SectionTitle({super.key, required this.title});

  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900));
}

class WalletTile extends StatelessWidget {
  final Wallet wallet;

  const WalletTile({super.key, required this.wallet});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final converted = app.toBase(wallet.balance, wallet.currencyCode);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ModernCard(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          CircleAvatar(child: Icon(wallet.icon)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(wallet.name, style: const TextStyle(fontWeight: FontWeight.w800)), Text('${wallet.type} • ${wallet.currencyCode}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12))])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(MoneyFormatter.format(wallet.balance, currency: wallet.currencyCode), style: const TextStyle(fontWeight: FontWeight.w900)), if (wallet.currencyCode != app.baseCurrency) Text('≈ ${MoneyFormatter.idr(converted)}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12))]),
        ]),
      ),
    );
  }
}

class TransactionTile extends StatelessWidget {
  final MoneyTransaction transaction;

  const TransactionTile({super.key, required this.transaction});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final category = app.categoryById(transaction.categoryId);
    final wallet = app.walletById(transaction.walletId);
    final isIncome = transaction.type == TransactionType.income;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ModernCard(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          CircleAvatar(backgroundColor: category.color.withOpacity(.13), foregroundColor: category.color, child: Icon(category.icon)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(category.name, style: const TextStyle(fontWeight: FontWeight.w800)), Text('${transaction.note} • ${wallet.name}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis)])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('${isIncome ? '+' : '-'}${MoneyFormatter.format(transaction.amount, currency: transaction.currencyCode)}', style: TextStyle(fontWeight: FontWeight.w900, color: isIncome ? const Color(0xFF10B981) : const Color(0xFFEF4444))),
            if (transaction.currencyCode != app.baseCurrency) Text('≈ ${MoneyFormatter.idr(app.toBase(transaction.amount, transaction.currencyCode))}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          ]),
        ]),
      ),
    );
  }
}

class TransactionsScreen extends StatelessWidget {
  const TransactionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Transaksi', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 120), children: [
          TextField(decoration: InputDecoration(hintText: 'Cari transaksi...', prefixIcon: const Icon(Icons.search_rounded), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none))),
          const SizedBox(height: 16),
          ...app.transactions.map((transaction) => TransactionTile(transaction: transaction)),
        ]),
      ),
    );
  }
}

class BudgetScreen extends StatelessWidget {
  const BudgetScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Budget', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 120), children: [
          ModernCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Sisa Budget Bulan Ini', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(MoneyFormatter.idr(app.remainingBudget), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            LinearProgressIndicator(value: app.totalBudget == 0 ? 0 : (app.monthlyExpense / app.totalBudget).clamp(0, 1), minHeight: 10, borderRadius: BorderRadius.circular(99)),
          ])),
          const SizedBox(height: 16),
          ...app.budgets.map((budget) {
            final category = app.categoryById(budget.categoryId);
            final spent = app.spentByCategory(category.id);
            final percent = budget.amountBase == 0 ? 0.0 : (spent / budget.amountBase).clamp(0.0, 1.0);
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ModernCard(child: Column(children: [
                Row(children: [
                  CircleAvatar(backgroundColor: category.color.withOpacity(.12), foregroundColor: category.color, child: Icon(category.icon)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(category.name, style: const TextStyle(fontWeight: FontWeight.w900)), Text('${MoneyFormatter.idr(spent)} dari ${MoneyFormatter.idr(budget.amountBase)}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12))])),
                  Text('${(percent * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w900)),
                ]),
                const SizedBox(height: 12),
                LinearProgressIndicator(value: percent, minHeight: 9, borderRadius: BorderRadius.circular(99)),
              ])),
            );
          }),
        ]),
      ),
    );
  }
}

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Laporan', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 120), children: [
          Row(children: [
            Expanded(child: MetricCard(title: 'Income', value: app.monthlyIncome, icon: Icons.trending_up_rounded, accent: const Color(0xFF10B981), currencyCode: app.baseCurrency)),
            const SizedBox(width: 12),
            Expanded(child: MetricCard(title: 'Expense', value: app.monthlyExpense, icon: Icons.trending_down_rounded, accent: const Color(0xFFEF4444), currencyCode: app.baseCurrency)),
          ]),
          const SizedBox(height: 16),
          ModernCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Pengeluaran per Kategori', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 16),
            ...app.categories.where((category) => category.type == TransactionType.expense).map((category) {
              final spent = app.spentByCategory(category.id);
              final percent = app.monthlyExpense == 0 ? 0.0 : spent / app.monthlyExpense;
              return Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(children: [
                Row(children: [Icon(category.icon, color: category.color, size: 20), const SizedBox(width: 8), Expanded(child: Text(category.name, style: const TextStyle(fontWeight: FontWeight.w700))), Text(MoneyFormatter.idr(spent), style: const TextStyle(fontWeight: FontWeight.w900))]),
                const SizedBox(height: 8),
                LinearProgressIndicator(value: percent.clamp(0.0, 1.0), minHeight: 8, borderRadius: BorderRadius.circular(99)),
              ]));
            }),
          ])),
          const SizedBox(height: 16),
          ModernCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Export Laporan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.picture_as_pdf_rounded), label: const Text('PDF'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.table_chart_rounded), label: const Text('CSV')))]),
          ])),
        ]),
      ),
    );
  }
}

class CurrencyScreen extends StatefulWidget {
  const CurrencyScreen({super.key});

  @override
  State<CurrencyScreen> createState() => _CurrencyScreenState();
}

class _CurrencyScreenState extends State<CurrencyScreen> {
  final amountController = TextEditingController(text: '100');
  String fromCode = 'USD';
  String toCode = 'IDR';

  @override
  void dispose() {
    amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final amount = double.tryParse(amountController.text.replaceAll('.', '').replaceAll(',', '.')) ?? 0;
    final converted = app.convertAmount(amount, fromCode, toCode);
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Kurs & Valas', style: TextStyle(fontWeight: FontWeight.w900)), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.refresh_rounded))]),
        body: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 120), children: [
          ModernCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFF10B981).withOpacity(.12), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.currency_exchange_rounded, color: Color(0xFF059669))),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Konverter Mata Uang', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), Text('Hitung otomatis berdasarkan kurs tengah demo.', style: TextStyle(fontSize: 12))])),
            ]),
            const SizedBox(height: 18),
            TextField(controller: amountController, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: InputDecoration(labelText: 'Nominal', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none))),
            const SizedBox(height: 12),
            Row(children: [Expanded(child: _CurrencyDropdown(value: fromCode, rates: app.currencyRates, onChanged: (value) => setState(() => fromCode = value))), const SizedBox(width: 10), IconButton(onPressed: () => setState(() { final old = fromCode; fromCode = toCode; toCode = old; }), icon: const Icon(Icons.swap_horiz_rounded)), const SizedBox(width: 10), Expanded(child: _CurrencyDropdown(value: toCode, rates: app.currencyRates, onChanged: (value) => setState(() => toCode = value)))]),
            const SizedBox(height: 16),
            Container(width: double.infinity, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF10B981).withOpacity(.10), borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Hasil Konversi', style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.w700)), const SizedBox(height: 6), Text(MoneyFormatter.format(converted, currency: toCode), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))])),
          ])),
          const SizedBox(height: 16),
          ModernCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Info Kurs', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text('Rate di starter ini adalah data contoh. Untuk produksi, aktifkan Supabase Edge Function agar rate diambil dari provider kurs dan disimpan ke database.', style: TextStyle(color: Colors.grey.shade600, height: 1.4)),
          ])),
          const SizedBox(height: 16),
          const SectionTitle(title: 'Daftar Kurs Lengkap'),
          const SizedBox(height: 10),
          ...app.currencyRates.where((rate) => rate.code != 'IDR').map((rate) => CurrencyRateTile(rate: rate)),
        ]),
      ),
    );
  }
}

class _CurrencyDropdown extends StatelessWidget {
  final String value;
  final List<CurrencyRate> rates;
  final ValueChanged<String> onChanged;

  const _CurrencyDropdown({required this.value, required this.rates, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      items: rates.map((rate) => DropdownMenuItem(value: rate.code, child: Text(rate.code))).toList(),
      onChanged: (value) {
        if (value != null) onChanged(value);
      },
      decoration: InputDecoration(filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)),
    );
  }
}

class CurrencyMiniCard extends StatelessWidget {
  final CurrencyRate rate;

  const CurrencyMiniCard({super.key, required this.rate});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ModernCard(padding: const EdgeInsets.all(14), child: Row(children: [
        CircleAvatar(child: Text(rate.code.substring(0, 1))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${rate.code} - ${rate.name}', style: const TextStyle(fontWeight: FontWeight.w900)), Text(rate.country, style: TextStyle(color: Colors.grey.shade600, fontSize: 12))])),
        Text(MoneyFormatter.rate(rate.midRateToIdr), style: const TextStyle(fontWeight: FontWeight.w900)),
      ])),
    );
  }
}

class CurrencyRateTile extends StatelessWidget {
  final CurrencyRate rate;

  const CurrencyRateTile({super.key, required this.rate});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ModernCard(padding: const EdgeInsets.all(14), child: Row(children: [
        CircleAvatar(child: Text(rate.code.substring(0, 1))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${rate.code} • ${rate.name}', style: const TextStyle(fontWeight: FontWeight.w900)), Text('${rate.country} • ${rate.source}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12))])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('Beli ${MoneyFormatter.rate(rate.buyRateToIdr)}', style: const TextStyle(fontWeight: FontWeight.w800)), Text('Jual ${MoneyFormatter.rate(rate.sellRateToIdr)}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12))]),
      ])),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Profil', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 120), children: [
        ModernCard(child: Row(children: [
          const CircleAvatar(radius: 28, child: Icon(Icons.person_rounded)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('RapiKas User', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Text(app.userEmail ?? 'demo@rapikas.app')])) ,
          IconButton(onPressed: app.logout, icon: const Icon(Icons.logout_rounded)),
        ])),
        const SizedBox(height: 16),
        const _ProfileMenu(icon: Icons.account_balance_wallet_rounded, title: 'Dompet Multi-Mata Uang'),
        const _ProfileMenu(icon: Icons.currency_exchange_rounded, title: 'Pengaturan Kurs'),
        const _ProfileMenu(icon: Icons.category_rounded, title: 'Kategori'),
        const _ProfileMenu(icon: Icons.flag_rounded, title: 'Target Keuangan'),
        const _ProfileMenu(icon: Icons.receipt_long_rounded, title: 'Tagihan & Cicilan'),
        const _ProfileMenu(icon: Icons.handshake_rounded, title: 'Utang & Piutang'),
        const _ProfileMenu(icon: Icons.backup_rounded, title: 'Backup & Sync'),
        const _ProfileMenu(icon: Icons.security_rounded, title: 'PIN & Biometric'),
        const _ProfileMenu(icon: Icons.language_rounded, title: 'Bahasa'),
      ]),
    );
  }
}

class _ProfileMenu extends StatelessWidget {
  final IconData icon;
  final String title;

  const _ProfileMenu({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ModernCard(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), child: Row(children: [Icon(icon), const SizedBox(width: 12), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800))), const Icon(Icons.chevron_right_rounded)])),
    );
  }
}

class AddTransactionSheet extends StatefulWidget {
  const AddTransactionSheet({super.key});

  @override
  State<AddTransactionSheet> createState() => _AddTransactionSheetState();
}

class _AddTransactionSheetState extends State<AddTransactionSheet> {
  TransactionType type = TransactionType.expense;
  final amountController = TextEditingController();
  final noteController = TextEditingController();
  String? walletId;
  String? categoryId;
  String? currencyCode;

  @override
  void dispose() {
    amountController.dispose();
    noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    walletId ??= app.wallets.first.id;
    currencyCode ??= app.walletById(walletId!).currencyCode;
    categoryId ??= app.categories.firstWhere((category) => category.type == type).id;
    final filteredCategories = app.categories.where((category) => category.type == type).toList();

    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Center(child: Container(width: 44, height: 5, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(999)))),
          const SizedBox(height: 18),
          const Text('Tambah Transaksi', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 16),
          SegmentedButton<TransactionType>(segments: const [ButtonSegment(value: TransactionType.expense, icon: Icon(Icons.arrow_upward_rounded), label: Text('Expense')), ButtonSegment(value: TransactionType.income, icon: Icon(Icons.arrow_downward_rounded), label: Text('Income'))], selected: {type}, onSelectionChanged: (value) => setState(() { type = value.first; categoryId = app.categories.firstWhere((category) => category.type == type).id; })),
          const SizedBox(height: 14),
          TextField(controller: amountController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Nominal', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none))),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(value: walletId, items: app.wallets.map((wallet) => DropdownMenuItem(value: wallet.id, child: Text('${wallet.name} (${wallet.currencyCode})'))).toList(), onChanged: (value) => setState(() { walletId = value; currencyCode = value == null ? currencyCode : app.walletById(value).currencyCode; }), decoration: InputDecoration(labelText: 'Dompet', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)))),
            const SizedBox(width: 10),
            Expanded(child: DropdownButtonFormField<String>(value: currencyCode, items: app.currencyRates.map((rate) => DropdownMenuItem(value: rate.code, child: Text(rate.code))).toList(), onChanged: (value) => setState(() => currencyCode = value), decoration: InputDecoration(labelText: 'Mata Uang', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)))),
          ]),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(value: categoryId, items: filteredCategories.map((category) => DropdownMenuItem(value: category.id, child: Text(category.name))).toList(), onChanged: (value) => setState(() => categoryId = value), decoration: InputDecoration(labelText: 'Kategori', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none))),
          const SizedBox(height: 14),
          TextField(controller: noteController, decoration: InputDecoration(labelText: 'Catatan', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none))),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: FilledButton(
              onPressed: () {
                final amount = double.tryParse(amountController.text.replaceAll('.', '').replaceAll(',', '.'));
                if (amount == null || amount <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan nominal yang valid.')));
                  return;
                }
                app.addTransaction(type: type, amount: amount, currencyCode: currencyCode!, walletId: walletId!, categoryId: categoryId!, note: noteController.text.trim().isEmpty ? 'Tanpa catatan' : noteController.text.trim());
                Navigator.pop(context);
              },
              style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
              child: const Text('Simpan Transaksi'),
            ),
          ),
        ]),
      ),
    );
  }
}
